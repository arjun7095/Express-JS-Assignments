import React from 'react';
//import Student from './student';
import DocDetails from './docDetails';


function App() {
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />
      <DocDetails />
    </>
  );
}

export default App;