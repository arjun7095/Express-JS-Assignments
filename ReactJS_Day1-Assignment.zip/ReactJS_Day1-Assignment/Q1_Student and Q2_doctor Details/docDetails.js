import React from "react";
 function DocDetails(){
    let docsArray = [
        { doctorid: 10, doctorName: "Arjun", designation: "Cardiologist",exp:'5 Years',contNumber:123456 },
        { doctorid: 20, doctorName: "Devi", designation: "Physician",exp:'6 Years',contNumber:923456 },
        { doctorid: 30, doctorName: "Sesi", designation: "Neurolist",exp:'7 Years',contNumber:823456 },
        { doctorid: 40, doctorName: "Sameer", designation: "Dermatolist",exp:'8 Years',contNumber:723456 },
        { doctorid: 50, doctorName: "Bhanu", designation: "Psychiatrists",exp:'9 Years',contNumber:623456 },
      ];
    let result = docsArray.map((item) => {
        return <tr>
          <td>   {item.doctorid}  </td>
          <td>   {item.doctorName}  </td>
          <td>   {item.designation}  </td>
          <td>   {item.exp}  </td>
          <td>   {item.contNumber}  </td>
        </tr>
      });
      return(
        <>
        <div>
        <h3>Doctor Details</h3>
        <table border="2" width="300" cellspacing="0" cellpadding="5">
          <tr>
            <th>Doctor ID</th>
            <th>Doctor Name</th>
            <th>Designation</th>
            <th>Experience</th>
            <th>Contact Number</th>
          </tr>
          {result}
        </table>
      </div>
      </>
    )
 }
 export default DocDetails;