import React from "react";

function Student(){
    let sid=1001;
    let sname='Arjun';
    let course='React';
    let age=24;
    let total=98;
    return(
        <>
        <h3>Student Details</h3>
        <div><table border="2" width="400" cellspacing="0" cellpadding="5">
            <tr><td>Student ID :</td> <td>{sid}</td></tr>
            <tr><td>Student Name :</td> <td>{sname}</td></tr>
            <tr><td>Student Course :</td> <td>{course}</td></tr>
            <tr><td>Student Age :</td> <td>{age}</td></tr>
            <tr><td>Student Total Marks :</td> <td>{total}</td></tr>
        </table>
        </div>
        </>
    )
}
export default Student;