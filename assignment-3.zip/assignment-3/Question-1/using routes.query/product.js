const express = require("express");
const router = express.Router();



router.get("/product", function (req, res) {   
    
    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 1, pname: "HP LaserJet Pro MFP M126nw Printer", qnty:2,price:22000,ctgry:"Electronics",image:"/images/printer.jfif" },
        { pid: 2, pname: "LG UHD TV UQ75 43 (108cm) 4K Smart TV",qnty:4,price:17000,ctgry:"Electronics" ,image:"/images/tv.jfif" },
        { pid: 3, pname: "Black T-Shirt", qnty:10,price:500,ctgry:"Cloths" ,image:"/images/blackt.jfif" },
        { pid: 4, pname: "Blue Jean",qnty:13,price:700,ctgry:"Cloths" ,image:"/images/bluejean.jfif" },
        { pid: 5, pname: "Samsung Single Door Refrigerator",qnty:6,price:22000,ctgry:"Electronics" ,image:"/images/fridge.jfif" },
        { pid: 6, pname: "8Kg Front Load Washing Machine",qnty:4,price:35000,ctgry:"Electronics",image:"/images/washing.jfif"  },
        { pid: 7, pname: "white Shirt",qnty:9,price:800,ctgry:"Cloths" ,image:"/images/whiteshirt.jfif" },
        { pid: 8, pname: "navy blue shirt",qnty:15,price:1200,ctgry:"Cloths" ,image:"/images/navyblue.jfif"},
        { pid: 9, pname: "Iron box",qnty:8,price:2000,ctgry:"Electronics" ,image:"/images/ironbox.jfif" },
        { pid: 10, pname: "Heater",qnty:11,price:300,ctgry:"Electronics" ,image:"/images/heater.jfif" },
        { pid: 11, pname: "Ton Jean",qnty:16,price:900,ctgry:"Cloths" ,image:"/images/tonjean.jfif" },
        { pid: 12, pname: "Cotton jeans",qnty:18,price:1200,ctgry:"Cloths" ,image:"/images/cottonjean.jfif" },
        { pid: 13, pname: "oven",qnty:3,price:17000,ctgry:"Electronics" ,image:"/images/oven.jfif"},
        { pid: 14, pname: "Bevel Cockatiel 750W Mixer Grinder",qnty:8,price:3000,ctgry:"Electronics"  ,image:"/images/mixer.jfif"},
        { pid: 15, pname: "Induction Cooker",qnty:4,price:6000,ctgry:"Electronics",image:"/images/induction.jfif"  },
        { pid: 16, pname: "Sleeve navy blue T-shirt",qnty:13,price:500,ctgry:"Cloths" ,image:"/images/sleavenavy.jfif" },
        { pid: 17, pname: "neck T shirt",qnty:15,price:450,ctgry:"Cloths",image:"/images/neck.jfif"  },
        { pid: 18, pname: "Hoodie",qnty:9,price:1200,ctgry:"Cloths" ,image:"/images/hoodie.jfif" },
        { pid: 19, pname: "Multi-Purpose Trimmer",qnty:7,price:1500,ctgry:"Electronics",image:"/images/trimmer.jfif"  },
        { pid: 20, pname: "Blue ton Jean",qnty:15,price:900,ctgry:"Cloths",image:"/images/blueton.jfif" },
    ];
    res.render("product", dataObj);
 
});
router.get("/GetDeptById", function (req, res) {

    var deptsArray = [
        { pid: 1, pname: "HP LaserJet Pro MFP M126nw Printer", qnty:2,price:22000,ctgry:"Electronics",image:"/images/printer.jfif" },
        { pid: 2, pname: "LG UHD TV UQ75 43 (108cm) 4K Smart TV",qnty:4,price:17000,ctgry:"Electronics" ,image:"/images/tv.jfif" },
        { pid: 3, pname: "Black T-Shirt", qnty:10,price:500,ctgry:"Cloths" ,image:"/images/blackt.jfif" },
        { pid: 4, pname: "Blue Jean",qnty:13,price:700,ctgry:"Cloths" ,image:"/images/bluejean.jfif" },
        { pid: 5, pname: "Samsung Single Door Refrigerator",qnty:6,price:22000,ctgry:"Electronics" ,image:"/images/fridge.jfif" },
        { pid: 6, pname: "8Kg Front Load Washing Machine",qnty:4,price:35000,ctgry:"Electronics",image:"/images/washing.jfif"  },
        { pid: 7, pname: "white Shirt",qnty:9,price:800,ctgry:"Cloths" ,image:"/images/whiteshirt.jfif" },
        { pid: 8, pname: "navy blue shirt",qnty:15,price:1200,ctgry:"Cloths" ,image:"/images/navyblue.jfif"},
        { pid: 9, pname: "Iron box",qnty:8,price:2000,ctgry:"Electronics" ,image:"/images/ironbox.jfif" },
        { pid: 10, pname: "Heater",qnty:11,price:300,ctgry:"Electronics" ,image:"/images/heater.jfif" },
        { pid: 11, pname: "Ton Jean",qnty:16,price:900,ctgry:"Cloths" ,image:"/images/tonjean.jfif" },
        { pid: 12, pname: "Cotton jeans",qnty:18,price:1200,ctgry:"Cloths" ,image:"/images/cottonjean.jfif" },
        { pid: 13, pname: "oven",qnty:3,price:17000,ctgry:"Electronics" ,image:"/images/oven.jfif"},
        { pid: 14, pname: "Bevel Cockatiel 750W Mixer Grinder",qnty:8,price:3000,ctgry:"Electronics"  ,image:"/images/mixer.jfif"},
        { pid: 15, pname: "Induction Cooker",qnty:4,price:6000,ctgry:"Electronics",image:"/images/induction.jfif"  },
        { pid: 16, pname: "Sleeve navy blue T-shirt",qnty:13,price:500,ctgry:"Cloths" ,image:"/images/sleavenavy.jfif" },
        { pid: 17, pname: "neck T shirt",qnty:15,price:450,ctgry:"Cloths",image:"/images/neck.jfif"  },
        { pid: 18, pname: "Hoodie",qnty:9,price:1200,ctgry:"Cloths" ,image:"/images/hoodie.jfif" },
        { pid: 19, pname: "Multi-Purpose Trimmer",qnty:7,price:1500,ctgry:"Electronics",image:"/images/trimmer.jfif"  },
        { pid: 20, pname: "Blue ton Jean",qnty:15,price:900,ctgry:"Cloths",image:"/images/blueton.jfif" },
     ];
 

    let pno = req.query.pno;
    let dataObj = {};    
    dataObj.deptObj = deptsArray.find( item => item.pid == pno);
 
    res.render("single-product", dataObj);
 });
 
module.exports = router;