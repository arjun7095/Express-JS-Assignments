const express = require("express");
const router = express.Router();



router.get("/electronics", function (req, res) {   
    
    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 1, pname: "HP LaserJet Pro MFP M126nw Printer", qnty:2,price:22000,ctgry:"Electronics",image:"/images/printer.jfif" },
        { pid: 2, pname: "LG UHD TV UQ75 43 (108cm) 4K Smart TV",qnty:4,price:17000,ctgry:"Electronics" ,image:"/images/tv.jfif" },
        { pid: 5, pname: "Samsung Single Door Refrigerator",qnty:6,price:22000,ctgry:"Electronics" ,image:"/images/fridge.jfif" },
        { pid: 6, pname: "8Kg Front Load Washing Machine",qnty:4,price:35000,ctgry:"Electronics",image:"/images/washing.jfif"  },
        { pid: 9, pname: "Iron box",qnty:8,price:2000,ctgry:"Electronics" ,image:"/images/ironbox.jfif" },
        { pid: 10, pname: "Heater",qnty:11,price:300,ctgry:"Electronics" ,image:"/images/heater.jfif" },
        { pid: 13, pname: "oven",qnty:3,price:17000,ctgry:"Electronics" ,image:"/images/oven.jfif"},
        { pid: 14, pname: "Bevel Cockatiel 750W Mixer Grinder",qnty:8,price:3000,ctgry:"Electronics"  ,image:"/images/mixer.jfif"},
        { pid: 15, pname: "Induction Cooker",qnty:4,price:6000,ctgry:"Electronics",image:"/images/induction.jfif"  },
        { pid: 19, pname: "Multi-Purpose Trimmer",qnty:7,price:1500,ctgry:"Electronics",image:"/images/trimmer.jfif"  },
        
    ];
    res.render("electronics", dataObj);
 
});
router.get("/GetDeptById/:id", function (req, res) {

    var deptsArray = [
        { pid: 1, pname: "HP LaserJet Pro MFP M126nw Printer", qnty:2,price:22000,ctgry:"Electronics",image:"/images/printer.jfif" },
        { pid: 2, pname: "LG UHD TV UQ75 43 (108cm) 4K Smart TV",qnty:4,price:17000,ctgry:"Electronics" ,image:"/images/tv.jfif" },
        { pid: 5, pname: "Samsung Single Door Refrigerator",qnty:6,price:22000,ctgry:"Electronics" ,image:"/images/fridge.jfif" },
        { pid: 6, pname: "8Kg Front Load Washing Machine",qnty:4,price:35000,ctgry:"Electronics",image:"/images/washing.jfif"  },
        { pid: 9, pname: "Iron box",qnty:8,price:2000,ctgry:"Electronics" ,image:"/images/ironbox.jfif" },
        { pid: 10, pname: "Heater",qnty:11,price:300,ctgry:"Electronics" ,image:"/images/heater.jfif" },
        { pid: 13, pname: "oven",qnty:3,price:17000,ctgry:"Electronics" ,image:"/images/oven.jfif"},
        { pid: 14, pname: "Bevel Cockatiel 750W Mixer Grinder",qnty:8,price:3000,ctgry:"Electronics"  ,image:"/images/mixer.jfif"},
        { pid: 15, pname: "Induction Cooker",qnty:4,price:6000,ctgry:"Electronics",image:"/images/induction.jfif"  },
        { pid: 19, pname: "Multi-Purpose Trimmer",qnty:7,price:1500,ctgry:"Electronics",image:"/images/trimmer.jfif"  },
     ];
 

    let pno = req.query.pno;
    let dataObj = {};    
    dataObj.deptObj = deptsArray.find( item => item.pid == pno);
 
    res.render("single-product", dataObj);
 });
 
module.exports = router;