const express = require("express");
const router = express.Router();



router.get("/cloths", function (req, res) {   
    
    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 3, pname: "Black T-Shirt", qnty:10,price:500,ctgry:"Cloths" ,image:"/images/blackt.jfif" },
        { pid: 4, pname: "Blue Jean",qnty:13,price:700,ctgry:"Cloths" ,image:"/images/bluejean.jfif" },
        { pid: 7, pname: "white Shirt",qnty:9,price:800,ctgry:"Cloths" ,image:"/images/whiteshirt.jfif" },
        { pid: 8, pname: "navy blue shirt",qnty:15,price:1200,ctgry:"Cloths" ,image:"/images/navyblue.jfif"},
        { pid: 11, pname: "Ton Jean",qnty:16,price:900,ctgry:"Cloths" ,image:"/images/tonjean.jfif" },
        { pid: 12, pname: "Cotton jeans",qnty:18,price:1200,ctgry:"Cloths" ,image:"/images/cottonjean.jfif" },
        { pid: 16, pname: "Sleeve navy blue T-shirt",qnty:13,price:500,ctgry:"Cloths" ,image:"/images/sleavenavy.jfif" },
        { pid: 17, pname: "neck T shirt",qnty:15,price:450,ctgry:"Cloths",image:"/images/neck.jfif"  },
        { pid: 18, pname: "Hoodie",qnty:9,price:1200,ctgry:"Cloths" ,image:"/images/hoodie.jfif" },
        { pid: 20, pname: "Blue ton Jean",qnty:15,price:900,ctgry:"Cloths",image:"/images/blueton.jfif" },
    ];
    res.render("cloths", dataObj);
 
});
router.get("/GetDeptById/:id", function (req, res) {

    var deptsArray = [
        { pid: 3, pname: "Black T-Shirt", qnty:10,price:500,ctgry:"Cloths" ,image:"/images/blackt.jfif" },
        { pid: 4, pname: "Blue Jean",qnty:13,price:700,ctgry:"Cloths" ,image:"/images/bluejean.jfif" },
        { pid: 7, pname: "white Shirt",qnty:9,price:800,ctgry:"Cloths" ,image:"/images/whiteshirt.jfif" },
        { pid: 8, pname: "navy blue shirt",qnty:15,price:1200,ctgry:"Cloths" ,image:"/images/navyblue.jfif"},
        { pid: 11, pname: "Ton Jean",qnty:16,price:900,ctgry:"Cloths" ,image:"/images/tonjean.jfif" },
        { pid: 12, pname: "Cotton jeans",qnty:18,price:1200,ctgry:"Cloths" ,image:"/images/cottonjean.jfif" },
        { pid: 16, pname: "Sleeve navy blue T-shirt",qnty:13,price:500,ctgry:"Cloths" ,image:"/images/sleavenavy.jfif" },
        { pid: 17, pname: "neck T shirt",qnty:15,price:450,ctgry:"Cloths",image:"/images/neck.jfif"  },
        { pid: 18, pname: "Hoodie",qnty:9,price:1200,ctgry:"Cloths" ,image:"/images/hoodie.jfif" },
        { pid: 20, pname: "Blue ton Jean",qnty:15,price:900,ctgry:"Cloths",image:"/images/blueton.jfif" },
     ];
 

    let pno = req.params.id;
    let dataObj = {};    
    dataObj.deptObj = deptsArray.find( item => item.pid == pno);
 
    res.render("single-product", dataObj);
 });
 
module.exports = router;