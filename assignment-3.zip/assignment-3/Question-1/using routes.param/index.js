var express = require("express");
var bodyParser = require("body-parser");  
const productRouter = require('./product');
const electronicsRouter = require('./electronics-route');
const clothsRouter = require('./cloths-route');



var app = express();   

app.use(bodyParser.urlencoded({extended : false}));
app.use(express.static('public'));

app.use("/allproducts", productRouter);
app.use("/category", electronicsRouter);
app.use("/category", clothsRouter);


app.set("view engine", "ejs");
app.use(express.static('public'));

app.get("/", function (req, res) {   
    res.render("home", {});
});


var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");