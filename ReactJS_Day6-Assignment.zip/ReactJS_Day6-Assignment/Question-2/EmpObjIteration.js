import React from "react";

function EmpObjIteration(){

    let empArray = [
        {empno:1001,ename:'arjun',email:'arjun@gmail.com',job:'Developer'},
        {empno:1002,ename:'devi',email:'devi@gmail.com',job:'Test Engineer'},
        {empno:1003,ename:'sesi',email:'sesi@gmail.com',job:'data Engineer'},
        {empno:1004,ename:'bhanu',email:'bhanu@gmail.com',job:'ASE'},
        {empno:1005,ename:'sameer',email:'sameer@gmail.com',job:'Bench APPS'},
    ]
    
    let resultArray  = empArray.map((item)=>{
      return <tr>
        {
          Object.values(item).map(value =><td>{value}</td>)
        }
      </tr>
    }
    )
    return (
      <table  border="2" cellSpacing="0" width="500">
       
          <tr>
            <th>Employess Number</th>
            <th>Employess Name</th>
            <th>Employess Email</th>
            <th>Employess Job</th>
          </tr>
     
        {resultArray}
      </table>
    );
    
  }


export default EmpObjIteration;