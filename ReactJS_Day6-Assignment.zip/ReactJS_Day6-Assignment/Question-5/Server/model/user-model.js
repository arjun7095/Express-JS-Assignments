//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(testDb is database name)
mongoose.connect('mongodb://127.0.0.1:27017/company');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var UserModelSchema = new Schema(
    {    
        name : String, 	
        email:String,
        password : String, 
          securityAnswer:String}, 
    { versionKey: false  } );

// Create Model Object	
var UserModel = mongoose.model('users', UserModelSchema );

// Exporting DeptModel 
module.exports = UserModel;
