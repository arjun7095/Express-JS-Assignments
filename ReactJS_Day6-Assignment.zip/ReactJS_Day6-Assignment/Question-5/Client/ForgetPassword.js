import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function ForgetPassword() {
  const [email, setEmail] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState('');

  let navigate = useNavigate();

  const handleResetPassword = async () => {
    try {
      const response = await axios.post('http://localhost:3007/api/resetPassword', { email, securityAnswer,newPassword });
      if(response.data.message){
        alert('password Reset Successful!')
        navigate('/Login')

      }
      else{
        alert('invalid email or security question')
        setMessage(response.data.message)
      }
    } catch (error) {
      console.error(error);
      setMessage('Password reset failed');
    }
  };

  return (
    <div align='center' style={ {backgroundColor:'aqua'}}>
      <h1>Forget Password</h1>
      <div>
        <label>Email:</label>
        <input type="text" value={email} placeholder='example@gmail.com' onChange={(e) => setEmail(e.target.value)} /><br/>
        
          <label>What is Your Nickname ?</label>
          <input type="text" value={securityAnswer} placeholder='Security Question' onChange={(e) => setSecurityAnswer(e.target.value)} /><br/>
          <label>New Password:</label>
          <input type="password" value={newPassword} placeholder='********' onChange={(e) => setNewPassword(e.target.value)} /><br/>
          <button onClick={handleResetPassword} >Reset Password</button>
        </div>
      
      <p style={ {paddingBottom:'50px'}}>{message && <p>{message}</p>}</p>
    </div>
  );
}

export default ForgetPassword;