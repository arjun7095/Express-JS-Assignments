import React,{ useContext } from "react";
import { userDetailsContext } from './App';


function Child3(){
 
    let resultArray = useContext(userDetailsContext).map (item => {
        return <tr>
          <td>{item.name}</td>
          <td>{item.age}</td>
          <td>{item.email}</td>
        </tr>
        });
    return(
        <div align="center" style={{margin:"10px", border:"2px solid Red"}}>
        <h3>This is Child3</h3>
        <table border="2" cellSpacing="0" width="500">
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Email</th>
            </tr>
        {resultArray}
      </table>
      </div>
    );
}

export default Child3;