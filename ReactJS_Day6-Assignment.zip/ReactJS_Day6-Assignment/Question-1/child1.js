import React from "react";
import Child2 from "./child2";
 
function Child1(){
    return(
        <div style={{margin:"10px", border:"2px solid Red"}}>
        <h2>This is Child1</h2>
        <Child2 />
        </div>
    );
}

export default Child1;