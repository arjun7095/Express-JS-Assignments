
import React from 'react';

import Child1 from './child1';
 
export var userDetailsContext  = React.createContext(null);


function App(){

  let userObj=[
    { name : "Scott", age : 25, email : "scott@gmail.com"},
    { name : "arjun", age : 24, email : "arjun@gmail.com"},
    { name : "devi", age : 35, email : "devi@gmail.com"},
    { name : "sesi", age : 25, email : "sesi@gmail.com"},
    { name : "Sameer", age : 26, email : "sameer@gmail.com"},
  ];
   
    return (
      <div style={{margin:"10px", border:"2px solid Blue"}}>  
        <h3>This is the Parent Component</h3>    
        <hr/>
        <userDetailsContext.Provider  value={userObj}>
            <Child1 />
        </userDetailsContext.Provider>  
          
      </div>
    );   
}

export default App;