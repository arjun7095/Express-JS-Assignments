import React from "react";
import Child3 from './child3';

function Child2(){
    return(
        <div style={{margin:"10px", border:"2px solid Red"}}>
        <h2>This is Child2</h2>
        <Child3 />
        </div>
    );
}

export default Child2;