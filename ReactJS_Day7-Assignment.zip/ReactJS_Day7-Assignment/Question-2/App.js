import BankApp from './Components/BankApp'; 
import React from 'react';
function App() 
{      
      return(
        <>
             <BankApp  />
        </>
        );
}

export default App;