var express = require("express");
var bodyParser = require("body-parser");  


var app = express();   

app.use(bodyParser.urlencoded({extended : false}));

app.set("view engine", "ejs");
app.use(express.static('public'));

app.get("/", function (req, res) {   
    res.render("home", {});
});

app.get("/product", function (req, res) {       
    res.render("product", {total:"" });
});

app.post("/product", function (req, res) {   
    
    let name = req.body.t1;
    let price = req.body.t2;
    let qnty = req.body.t3;
    total = price*qnty;
    res.render("product", {total});  
});



var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");