//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(testDb is database name)
mongoose.connect('mongodb://127.0.0.1:27017/mall');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var ProductsModelSchema = new Schema(
    {   prodid: Number, 
        Name : String, 	
        price : Number ,
        quantity:Number,
        makeBy : String,
        madeIn:String
         }, 
    { versionKey: false  } );

// Create Model Object	
// "depts"   --- collection name in mongodb
var ProductstModel = mongoose.model('products', ProductsModelSchema );

// Exporting DeptModel 
module.exports = ProductstModel;
