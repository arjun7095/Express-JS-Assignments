import React from 'react';

import DeptsMernStack from './DeptsMernStack';

function App() {
  
  return (
    <>
     <DeptsMernStack/>
    </>
  );
}

export default App;