import axios from 'axios';

export let dataSericeObj = 
{
    getAllDepartment,
    getDepartmentById,
    addDeparment,
    updateDepartment,
    deleteDepartment
};

const url = "http://localhost:3005/api/depts/";

function getAllDepartment()
{
    return axios.get(url);
}

function getDepartmentById(id)
{
    return axios.get(url + id);
}

function deleteDepartment(id)
{
    return axios.delete(url + id);
}

function addDeparment(deptObj)
{
    return axios.post(url, deptObj);
}

function updateDepartment(deptObj)
{
    return axios.put(url, deptObj);
}