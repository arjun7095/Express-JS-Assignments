import React from 'react';

import EmpDetails from './EmpDetailsWithJSON';

function App() {
  
  return (
    <>
     <EmpDetails/>
    </>
  );
}

export default App;