import React from 'react';
import StudentMernStack from './StudentMernStack';

function App() {
  
  return (
    <>
     <StudentMernStack/>
    </>
  );
}

export default App;