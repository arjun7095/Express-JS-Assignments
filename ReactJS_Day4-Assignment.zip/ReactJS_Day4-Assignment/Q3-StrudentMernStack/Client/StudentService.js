import axios from 'axios';

export let dataSericeObj = 
{
    getAllStudents,
    getStudentById,
    addStudent,
    updateStudent,
    deleteStudents
};

const url = "http://localhost:3005/api/student/";

function getAllStudents()
{
    return axios.get(url);
}

function getStudentById(id)
{
    return axios.get(url + id);
}

function addStudent(studentObj)
{
    return axios.post(url, studentObj);
}

function updateStudent(studentObj)
{
    return axios.put(url, studentObj);
}

function deleteStudents(id)
{
    return axios.delete(url + id);
}