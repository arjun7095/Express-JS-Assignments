import { useState } from 'react';
import React from 'react';
import {dataSericeObj} from './StudentService';

function StudentMernStack() {   

   const [studentsArray, setStudentsArray] = useState([]);
   const [rollNo,setRollno]=useState('');
   const [name,setName]=useState('');
   const [email,setEmail]=useState('');
   const [phoneno,setPhoneno]=useState('');
   const [standard,setStandard]=useState('');

  function getDataButton_click() {

    dataSericeObj.getAllStudents().then((resData) => {
      setStudentsArray(resData.data);
    });

  }

  function addStudentButton_click() {
    
    let studentObj = {};
    studentObj.Rollno = rollNo;
    studentObj.Name = name;
    studentObj.Email = email;
    studentObj.Phoneno = phoneno;
    studentObj.Standard = standard;
      

    dataSericeObj.addStudent(studentObj).then((resData) => {
      alert(resData.data.status);
      clearFields();
      getDataButton_click();
    });
    
}

function clearFields()
{
  setRollno("");
  setName("");
  setEmail(""); 
  setPhoneno(""); 
  setStandard(""); 
}
function updateStudentButton_click() {

  let studentObj = {};
    studentObj.Rollno = rollNo;
    studentObj.Name = name;
    studentObj.Email = email;
    studentObj.Phoneno = phoneno;
    studentObj.Standard = standard;

    dataSericeObj.updateStudent(studentObj).then((resData) => {
      alert(resData.data.status);
      clearFields();
      getDataButton_click();    
    });
}
function selectStudent_click(sno) { 

  dataSericeObj.getStudentById(sno).then((resData) => 
    {
  let studentsObj = resData.data;
  setRollno(studentsObj.Rollno);
  setName(studentsObj.Name);
  setEmail(studentsObj.Email);            
  setPhoneno(studentsObj.Phoneno);            
  setStandard(studentsObj.Standard);     
});       
}
function deletStudent_click(sno) {

  let flag = window.confirm("Are you sure want to delete?");    
  if(  flag === false   )
  {
      return;
  }

  dataSericeObj.deleteStudents(sno).then((resData) => {
    alert(resData.data.status);
    getDataButton_click();
  });
}

  let resultArray = studentsArray.map(item => 
    {
      return <tr>
          <td>{item.Rollno}</td>
          <td>{item.Name}</td>
          <td>{item.Email}</td>
          <td>{item.Phoneno}</td>
          <td>{item.Standard}</td>
          <td>
            <a href="javascript:void(0);" onClick={() => deletStudent_click(item.Rollno)}><img  src="images/delete.png" alt="delete" width="20"  /></a> 
          </td>
            <span>&nbsp;&nbsp;</span>
          <td>
            <a href="javascript:void(0);" onClick={() => selectStudent_click(item.Rollno)}><img  src="images/select.png"  width="20"  /></a>
          </td>
        </tr>;
      
    });


  return (
    <div style={ {"border":"2px solid blue", "padding":"10px", "padding-bottom":"15px", "backgroundColor" : "aqua"}}> 

      <h3>MERN Stack Implementation --- Student Details</h3>
      <hr/>
      <input type="text" placeholder="Roll No" value={rollNo} onChange={ (e) => setRollno(e.target.value)} /><br/>
      <input type="text" placeholder=" Name" value={name} onChange={ (e) => setName(e.target.value)} /><br/>
      <input type="text" placeholder="Email" value={email} onChange={ (e) => setEmail(e.target.value)} /><br/>
      <input type="text" placeholder="Phone NO" value={phoneno} onChange={ (e) => setPhoneno(e.target.value)} /><br/>
      <input type="text" placeholder="Standard" value={standard} onChange={ (e) => setStandard(e.target.value)} />

      <hr/>
      <input type="button" onClick={getDataButton_click} value="Get Data" />
      <input type="button" onClick={addStudentButton_click} value="Add Student" />
      <input type="button" onClick={updateStudentButton_click} value="Update Dept" />

      <hr/>

      <table  border="2" cellSpacing="0" width="500">
          <tr>
            <th>Roll No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No</th>
            <th>standard</th>
            
          </tr>
          {resultArray} 
      </table>         
        
    </div>
  );
}

export default StudentMernStack;