import React from "react";
function About()
{  
    return <div style={{backgroundColor:'LightPink', padding: '10px'}}>
        <h1>About</h1>  
        <p>This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. </p>
        <p>This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. </p>
    </div>
}  

export default About;
 

 