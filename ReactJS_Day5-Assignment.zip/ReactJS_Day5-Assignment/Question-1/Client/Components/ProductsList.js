import React from 'react';

function ProductsList(props){
   
    const productsData = [
        { id: 1, name: 'Vivo',price:1000, category: 'Mobiles' },
        { id: 2, name: 'Hp', price:2000,category: 'Laptops' },
        { id: 3, name: 'One Plus',price:3000, category: 'Mobiles' },
        { id: 4, name: 'Dell', price:4000,category: 'Laptops' },
        { id: 5, name: 'Samsung',price:6000, category: 'Mobiles' },
        { id: 6, name: 'Lenovo', price:5000,category: 'Laptops' },
        { id: 7, name: 'Iphone',price:7000, category: 'Mobiles' },
       
    ];

    const filteredProducts = props.category ? productsData.filter((product) => product.category === props.category) : productsData;

    return (
        <div >
            <h2>Products List</h2>
            {filteredProducts.map((product, index) => (
                <div 
                key={product.id}
                style={ {backgroundColor: index % 2 === 0 ? 'aqua' : 'white',border : "2px solid black", padding :  "1px", 
                        margin :  "2px",borderTopWidth :  "20px", borderRadius :  "10px", width : "250px" ,float:"left" ,} }>
              
                <h3 align='center'>{product.name}</h3><hr/>
                Category: {product.category}<br/>
                Price: {product.price}<br/>
                <button className="btn btn-danger" ><a href="javascript:void()0" text-decoration="none">Add To Cart</a></button>
                
              </div>
            ))}
          </div>
            
    );
};

export default ProductsList;
