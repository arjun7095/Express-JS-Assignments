import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import './index.css';
import App from './App';
import Contact from './Components/Contact';
import About from './Components/About';
import DeptsMernStack from './Components/DeptsMernStack'
import NotFound from './Components/NotFound';

import Login from './Components/Login';
import ProtectedRoute from './Components/ProtectedRoute';
import StudentMernStack from './Components/StudentMernStack';



const routing = (
  <Router>
    <h3 style={{ textAlign: "center" }}>Routing Implementation using React JS Applications</h3>
    <hr />
    <div style={{ textAlign: "center", }}>
      <Link to="/">Home</Link> |
      <Link to="/Depts">Departments</Link> |
      <Link to="/student">Students</Link> |
      <Link to="/About">About Us</Link> |
      <Link to="/Contact">Contac Us</Link> |
      <Link to="/Login">Login</Link> |
    </div>
    <hr />
    <Routes>
      <Route path="/" element={<App />} />

      <Route path="/Depts" element={
        <ProtectedRoute  returnUrl="/Depts">
          <DeptsMernStack />
        </ProtectedRoute>
      } />
      <Route path="/student" element={
        <ProtectedRoute  returnUrl="/student">
          <StudentMernStack />
        </ProtectedRoute>
      } />
       
      <Route path="/Contact" element={<Contact />} />
      <Route path="/About" element={<About />} />
      <Route path="/Login" element={<Login />} />
      

      <Route path="*" element={<NotFound />} />
    </Routes>



  </Router>
);




const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing}
  </React.StrictMode>
);