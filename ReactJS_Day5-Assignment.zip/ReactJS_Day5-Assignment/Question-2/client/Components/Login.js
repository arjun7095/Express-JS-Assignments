import React, {useState} from 'react';
import { useLocation, useNavigate} from "react-router-dom";
import axios from 'axios';

function Login() {   

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    let navigate = useNavigate();
    let location = useLocation();
  
    const handleLogin = async () => {
      try {
        const queryString = location.search;
        let strReturnUrl  =  new URLSearchParams(queryString).get('returnUrl');
        const response = await axios.post('http://localhost:3006/api/login', { username, password });
        if(strReturnUrl == null)
        {
          strReturnUrl = "/";
        }
        if (response.data.success) {

          let token = "ASJDFJF87ADF8745LK4598SAD7FAJSDF45JSDLFKAS";
          sessionStorage.setItem('user-token', token);

          navigate(strReturnUrl)
          alert('Login successful');
        } 
        else {
         alert('Invalid credentials');
        }
      } catch (error) {
        console.error('Error during login:', error.message);
      }
    };
  
    return (
      <div align='center' style={ {backgroundColor:'aqua'}} >
        <h1>Login Page</h1>
        Enter Username: <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} style={ {margin:'10px'}}/> <br/>
        Enter Password: <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={ {margin:'10px'}}/><br/>
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }
  
  

export default Login;
