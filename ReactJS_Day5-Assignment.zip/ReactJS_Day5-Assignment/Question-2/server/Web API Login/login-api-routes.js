const express = require("express");
const LoginModel = require('./model/login-model');
const router = express.Router();


router.post('/login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const user = await LoginModel.findOne({ username, password });
      if (user) {
        res.json({ success: true });
      } else {
        res.json({ success: false, message: 'Invalid credentials' });
      }
    } catch (error) {
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

module.exports = router;