var app = express();

app.get('/',function(req,res){
    let str="<h1 align='center'>Web Application of Express JS</h1><hr>";
    str += "<div>";
    str += "Employee Id :  2586720<br>";
    str += "Employee Name  :  Boyapati Durgamallikarjuna<br>";
    str += "Employee Job : Associate Software Engineer<br>";
    str += "Employee Deptno :  10<br>";
    str += "Employee EmailID : boyapatidurga8@gmail.com<br>";
    str += "</div>";

    res.send(str);
});

var server = app.listen(3002, function(){});
console.log('Express JS Application is started. Browse at the Url: https://localhost:3002');