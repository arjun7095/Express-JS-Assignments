var express = require("express");

var app = express();

app.get('/',function(req,res){
    let empid = 2586720;
    let empname= ' Boyapati Durgamallikarjuna';
    let empjob = 'Associate Software Engineer';
    let empdeptid = 10;
    let empemail = 'boyapatidurga8@gmail.com';

    let str="<h1 align='center'>Web Application of Express JS</h1><hr>";
    str += `<div style="color:blue;font-family:Georgia,sans,sarif;">
        Employee Id :  ${empid}<br>
        Employee Name  : ${empname}<br>
        Employee Job : ${empjob}<br>
        Employee Deptno :  ${empdeptid}<br>
        Employee EmailID : ${empemail}<br>
        </div>`;

    res.send(str);
});

var server = app.listen(3002, function(){});
console.log('Express JS Application is started. Browse at the Url: https://localhost:3002');