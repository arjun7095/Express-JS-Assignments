import { useState } from "react";
import React from "react";

function EmpDetails() {

    const [empArray, setEmpArray] = useState([]);

    const [empno, setEmpno] = useState("");
    const [ename, setEname] = useState("");
    const [job, setJob] = useState("");
    const [sal, setSal] = useState("");
    const [deptno, setDeptno] = useState("");


    function getEmpButton_click() {
        let tempArray = [
            { empno: 1001, ename: "Arjun", job: "Senior Engineer",sal:1000000,deptno:10 },
            { empno: 1002, ename: "Sesi", job: "Junior Engineer",sal:900000,deptno:20 },
            { empno: 1003, ename: "Devi", job: "Data Engineer",sal:800000,deptno:20 },
            { empno: 1004, ename: "Bhanu", job: "React Enginee",sal:700000,deptno:30 },
            { empno: 1005, ename: "Sameer", job: "Junior Engineer",sal:600000,deptno:10 },
            
        ];

        setEmpArray(tempArray);
    }

    function updateEmpButton_click() {

        let tempArray = [...empArray];       
        
        let index = tempArray.findIndex(item => item.empno === empno);       
        tempArray[index].ename = ename;
        tempArray[index].job = job;
        tempArray[index].sal = sal;
        tempArray[index].deptno = deptno;

        setEmpArray(tempArray); 
        clearFields();
    }


    function clearFields()
    {
        setEmpno("");
        setEname("");
        setJob("");
        setSal("");
        setDeptno(""); 
    }

    function addEmpButton_click() {

        let tempArray = [...empArray];       
        
        let empObj = {};
        empObj.empno = empno;
        empObj.ename = ename;
        empObj.job = job;
        empObj.sal = sal;
        empObj.deptno = deptno;
        tempArray.push(empObj);        

        setEmpArray(tempArray);


        clearFields();


    }


    function deleteEmp_click(eno) {

        let tempArray = [...empArray];    // cloning original array into temp array
        let index = tempArray.findIndex(item => item.empno === eno);
        tempArray.splice(index, 1);
        setEmpArray(tempArray);
    }
   
    function selectEmp_click(eno) { 

        let tempArray = [...empArray];   
        let empObj = tempArray.find(item => item.empno === eno);
        setEmpno(empObj.empno);
        setEname(empObj.ename);
        setJob(empObj.job);            
        setSal(empObj.sal);            
        setDeptno(empObj.deptno);            
    }

    let resultArray2 = empArray.map((item) => {
        return <tr>
            <td>   {item.empno}  </td>
            <td>   {item.ename}  </td>
            <td>   {item.job}  </td>
            <td>   {item.sal}  </td>
            <td>   {item.deptno}  </td>
            <td>
                <a href="javascript:void(0)" onClick={() => deleteEmp_click(item.empno)}><img  src="images/delete.png" alt="delete" width="20"  /></a>
                
            </td>
            <td>
            <a href="javascript:void(0)" onClick={() => selectEmp_click(item.empno)}><img  src="images/select.png" alt="select" width="20"  /></a>

            </td>
            
        </tr>
    });
   
    return (
        <>
            <h3>Working with State -- CRUD Operations on Array of Objects</h3>
            <hr />

            <input type="text" placeholder="Employee Number" value={empno} onChange={ (e) => setEmpno(e.target.value)} />
            <input type="text" placeholder="Employee Name" value={ename} onChange={ (e) => setEname(e.target.value)} />
            <input type="text" placeholder="Job" value={job} onChange={ (e) => setJob(e.target.value)} />
            <input type="text" placeholder="salary" value={sal} onChange={ (e) => setSal(e.target.value)} />
            <input type="text" placeholder="Dept Number" value={deptno} onChange={ (e) => setDeptno(e.target.value)} />
            <hr/>
            <input type="button" onClick={getEmpButton_click} value="Get Emp" />
            <input type="button" onClick={addEmpButton_click} value="Add Emp" />
            <input type="button" onClick={updateEmpButton_click} value="Update Emp" />
            <hr />

            <table border="2" width="400" cellspacing="0" cellpadding="5">
                <tr>
                    <th>Employee Number</th>
                    <th>Employee Name</th>
                    <th>Job</th>
                    <th>Salary</th>
                    <th>Dept Number</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
                {resultArray2}
            </table>
            
        </>
    );
}

export default EmpDetails;