import React from 'react';
//import Crud from './crud_with_update';
//import Product from './product';
import EmpDetails from './empDetails';

function App() {
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

      <EmpDetails />
    </>
  );
}

export default App;