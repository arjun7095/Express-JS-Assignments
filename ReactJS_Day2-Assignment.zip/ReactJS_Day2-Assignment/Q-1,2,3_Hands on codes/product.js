import { useState } from "react";
import React from "react";

function Price() {
    const [pname,setPname]=useState("");
    const [price, setPrice] = useState(0);
    const [quantity, setQuantity] = useState(0);
    const [result, setResult] = useState(0)

    function buttonClick() {
        setResult(price*quantity);

    }
    return (
        <>
            <h3>Event Handling in React JS</h3>
            <hr />
            <fieldset>
                <legend>Total Price</legend>
                Product Name: <input type="text" value={pname} onChange={(e)=>setPname(e.target.value)} /><br/>
                Price :<input type="number" value={price} onChange={(e)=>setPrice(e.target.value)}/> <br></br>
                Quantity : <input type="number" value={quantity} onChange={(e)=>setQuantity(e.target.value)}/>  <br></br>
                <input type="button" onClick={buttonClick} value="Get Message" />
                <p>The Total cost of {pname} is {result}.</p>
            </fieldset>

        </>
    );
}

export default Price;