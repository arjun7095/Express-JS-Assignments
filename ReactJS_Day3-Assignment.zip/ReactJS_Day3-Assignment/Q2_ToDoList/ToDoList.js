

import React from 'react';

function ToDoList(props) {
  return (
    <ul>
      {props.tasks.map((task, index) => (
        <div key={index} align='center'>
          <div align="center" style={ {"width":"200px","border":"1px solid black",'width':'50%',"backgroundColor":'aqua'}}>
            {task} 
            <img src="images/delete.png" onClick={() => props.removeTask(index)} align="right" width="20"  /></div>
     
        </div>
      ))}
    </ul>
  );
};

export default ToDoList;
