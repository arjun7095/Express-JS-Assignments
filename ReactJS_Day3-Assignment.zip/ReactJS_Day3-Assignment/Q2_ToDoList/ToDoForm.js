
import React, { useState } from 'react';

function ToDoForm(props) {
  const [task, setTask] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (task.trim()) {
      props.addTask(task);
      setTask('');
    }
  };

  return (
    <form onSubmit={handleSubmit} align='center' >
      <input width='40%'type="text"placeholder="Add a new task"value={task}onChange={(e) => setTask(e.target.value)} />
     
      <button type="submit">Add Task</button>
    </form>
  );
};

export default ToDoForm;
