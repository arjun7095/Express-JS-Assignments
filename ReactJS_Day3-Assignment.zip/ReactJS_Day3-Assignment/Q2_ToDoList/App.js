

import React, { useState } from 'react';
import ToDoForm from './ToDoForm';
import ToDoList from './ToDoList';

function App(){
  const [tasks, setTasks] = useState([]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const removeTask = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks.splice(index, 1);
    setTasks(updatedTasks);
  };

  return (
    < >
    <div style={ {'height':'100%','width':'100%',}}>
      <h3 align='center' style={ {"margin-top":"10%"}}>ToDo List App</h3>
      <ToDoForm addTask={addTask} />
      <ToDoList tasks={tasks} removeTask={removeTask} />
    </div>
    </>
  );
};

export default App;
