import React, { useState } from 'react';
import ProductsList from './ProductsList'; 



function App() {
  const [selectedCategory,setSelectedCategory]=useState('');
  function categoryChange(e){
    setSelectedCategory(e.target.value);
  };

  function allProducts(){
    selectedCategory("");
  }
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

      <div>
        <label for='category' >Select A category:</label>
        <select id='category' value={selectedCategory} onChange={categoryChange}>
          <option value="">AlL Products</option>
          <option value="Mobiles">Mobiles</option>
          <option value="Laptops">Laptops</option>
        </select>

        {selectedCategory !== ''? (<ProductsList category={selectedCategory}/>):(<ProductsList />)}
     
      </div>
    </>
  );
}